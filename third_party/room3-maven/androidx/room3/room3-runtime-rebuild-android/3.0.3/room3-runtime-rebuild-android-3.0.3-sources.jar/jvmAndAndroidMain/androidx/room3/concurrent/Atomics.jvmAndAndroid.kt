/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

@file:JvmName("Atomics_jvmAndroidKt")
@file:RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)

package androidx.room3.concurrent

import androidx.annotation.RestrictTo

@Suppress("TypealiasDefinition")
public actual typealias AtomicInt = java.util.concurrent.atomic.AtomicInteger

internal typealias AtomicLong = java.util.concurrent.atomic.AtomicLong

@Suppress("TypealiasDefinition")
public actual typealias AtomicBoolean = java.util.concurrent.atomic.AtomicBoolean
