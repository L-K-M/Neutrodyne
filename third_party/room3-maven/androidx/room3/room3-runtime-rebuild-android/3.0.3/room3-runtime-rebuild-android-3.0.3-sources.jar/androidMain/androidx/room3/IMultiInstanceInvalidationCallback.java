/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /Volumes/Android/buildbot/src/android/androidx-room3-release/prebuilts/fullsdk-darwin/build-tools/36.0.0/aidl -o/Volumes/Android/buildbot/src/android/androidx-room3-release/out/androidx/room3/room3-runtime/build/generated/source/stable_aidl/androidMain -I/Volumes/Android/buildbot/src/android/androidx-room3-release/frameworks/support/room3/room3-runtime/src/androidMain/stableAidl -I/Volumes/Android/buildbot/src/android/androidx-room3-release/out/androidx/room3/room3-runtime/build/stableAidl -I/Volumes/Android/buildbot/src/android/androidx-room3-release/frameworks/support/room3/room3-runtime/src/androidMain/stableAidlImports -I/Volumes/Android/buildbot/src/android/androidx-room3-release/out/androidx/room3/room3-runtime/build/stableAidlImports -I/Volumes/Android/buildbot/src/android/androidx-room3-release/frameworks/support/buildSrc/stableAidlImports -d/Volumes/Android/buildbot/src/android/androidx-room3-release/out/tmp/aidl4955829267016273936.d --structured --min_sdk_version=23 --version=1 /Volumes/Android/buildbot/src/android/androidx-room3-release/frameworks/support/room3/room3-runtime/src/androidMain/stableAidl/androidx/room3/IMultiInstanceInvalidationCallback.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package androidx.room3;
/** RPC Callbacks for {@link IMultiInstanceInvalidationService}. */
@androidx.annotation.RestrictTo(androidx.annotation.RestrictTo.Scope.LIBRARY)
public interface IMultiInstanceInvalidationCallback extends android.os.IInterface
{
  /**
   * The version of this interface that the caller is built against.
   * This might be different from what {@link #getInterfaceVersion()
   * getInterfaceVersion} returns as that is the version of the interface
   * that the remote object is implementing.
   */
  public static final int VERSION = 1;
  /** Default implementation for IMultiInstanceInvalidationCallback. */
  public static class Default implements androidx.room3.IMultiInstanceInvalidationCallback
  {
    /**
     * Called when invalidation is detected in another instance of the same database.
     * 
     * @param tables List of invalidated table names
     */
    @Override public void onInvalidation(java.lang.String[] tables) throws android.os.RemoteException
    {
    }
    @Override
    public int getInterfaceVersion() {
      return 0;
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements androidx.room3.IMultiInstanceInvalidationCallback
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an androidx.room3.IMultiInstanceInvalidationCallback interface,
     * generating a proxy if needed.
     */
    public static androidx.room3.IMultiInstanceInvalidationCallback asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof androidx.room3.IMultiInstanceInvalidationCallback))) {
        return ((androidx.room3.IMultiInstanceInvalidationCallback)iin);
      }
      return new androidx.room3.IMultiInstanceInvalidationCallback.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      else if (code == TRANSACTION_getInterfaceVersion) {
        reply.writeNoException();
        reply.writeInt(getInterfaceVersion());
        return true;
      }
      switch (code)
      {
        case TRANSACTION_onInvalidation:
        {
          java.lang.String[] _arg0;
          _arg0 = data.createStringArray();
          this.onInvalidation(_arg0);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements androidx.room3.IMultiInstanceInvalidationCallback
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      private int mCachedVersion = -1;
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /**
       * Called when invalidation is detected in another instance of the same database.
       * 
       * @param tables List of invalidated table names
       */
      @Override public void onInvalidation(java.lang.String[] tables) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStringArray(tables);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onInvalidation, _data, null, android.os.IBinder.FLAG_ONEWAY);
          if (!_status) {
            throw new android.os.RemoteException("Method onInvalidation is unimplemented.");
          }
        }
        finally {
          _data.recycle();
        }
      }
      @Override
      public int getInterfaceVersion() throws android.os.RemoteException {
        if (mCachedVersion == -1) {
          android.os.Parcel data = android.os.Parcel.obtain();
          android.os.Parcel reply = android.os.Parcel.obtain();
          try {
            data.writeInterfaceToken(DESCRIPTOR);
            boolean _status = mRemote.transact(Stub.TRANSACTION_getInterfaceVersion, data, reply, 0);
            reply.readException();
            mCachedVersion = reply.readInt();
          } finally {
            reply.recycle();
            data.recycle();
          }
        }
        return mCachedVersion;
      }
    }
    static final int TRANSACTION_onInvalidation = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_getInterfaceVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 16777214);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "androidx$room3$IMultiInstanceInvalidationCallback".replace('$', '.');
  /**
   * Called when invalidation is detected in another instance of the same database.
   * 
   * @param tables List of invalidated table names
   */
  public void onInvalidation(java.lang.String[] tables) throws android.os.RemoteException;
  public int getInterfaceVersion() throws android.os.RemoteException;
}
